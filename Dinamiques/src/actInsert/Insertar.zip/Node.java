public class Node {
    int info;
    Node next; // la variabe tipo node serveix per enlleçar diferents nodes del mateix tipo

    public Node(int info) {
        this.info = info;
        this.next = null;
    }
}
