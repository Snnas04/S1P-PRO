import java.awt.*;

public interface Drawing {
    void draw(int width, int height, int level, Graphics2D graphics2D);
}
